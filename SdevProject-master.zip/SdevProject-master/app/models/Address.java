package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Address extends Model {
    @Id
    private Long id;
    
    @Constraints.Required
    private String street;

    @Constraints.Required
    private String county;

    @Constraints.Required
    private String postal_code;

    @OneToOne
    private Employee employee;

    public Address() {
    }

    public Address(Long id, String street, String county, String postal_code, Employee employee) {
        this.id = id;
        this.street=street;
        this.county=county;
        this.postal_code=postal_code;
        this.employee=employee;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStreet(){
        return this.street;
    }
    public void setStreet(String street){
        this.street=street;
    }
    public String getCounty(){
        return this.county;
    }
    public void setCounty(String county){
        this.county=county;
    }
    public void setpostal_code(String postal_code){
        this.postal_code=postal_code;
    }
    public String getpostal_code(){
        return this.postal_code;
    }

    public void setEmployee(Employee employee){
        this.employee=employee;
    }
    public Employee getEmployee(){
        return this.employee;
    }

    public static Finder<Long, Address> find = new Finder<Long, Address>(Address.class);

    public static List<Address> findAll() {
        return Address.find.query().where().orderBy("id asc").findList();
    }

    

}